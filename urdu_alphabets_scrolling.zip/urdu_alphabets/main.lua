-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

local sound_alif 		= audio.loadSound( "alphabets_sounds/alif.wav" )
local sound_bay 		= audio.loadSound( "alphabets_sounds/bay.wav" )
local sound_pay 		= audio.loadSound( "alphabets_sounds/alif.wav" )
local sound_tey 		= audio.loadSound( "sound_alif.wav" )
local sound_ttey 		= audio.loadSound( "sound_alif.wav" )
local sound_sey 		= audio.loadSound( "sound_alif.wav" )
local sound_jeem 		= audio.loadSound( "sound_alif.wav" )
local sound_chey 		= audio.loadSound( "sound_alif.wav" )
local sound_hey 		= audio.loadSound( "sound_alif.wav" )
local sound_khey 		= audio.loadSound( "sound_alif.wav" )
local sound_dal 		= audio.loadSound( "sound_alif.wav" )
local sound_ddal 		= audio.loadSound( "sound_alif.wav" )
local sound_zal 		= audio.loadSound( "sound_alif.wav" )
local sound_rey 		= audio.loadSound( "sound_alif.wav" )
local sound_rrey 		= audio.loadSound( "sound_alif.wav" )
local sound_zey 		= audio.loadSound( "sound_alif.wav" )
local sound_ssey 		= audio.loadSound( "sound_alif.wav" )
local sound_seen 		= audio.loadSound( "sound_alif.wav" )
local sound_sheen 		= audio.loadSound( "sound_alif.wav" )
local sound_suad 		= audio.loadSound( "sound_alif.wav" )
local sound_zuad 		= audio.loadSound( "sound_alif.wav" )
local sound_tua 		= audio.loadSound( "sound_alif.wav" )
local sound_zua 		= audio.loadSound( "sound_alif.wav" )
local sound_aen 		= audio.loadSound( "sound_alif.wav" )
local sound_ghaen 		= audio.loadSound( "sound_alif.wav" )
local sound_fey 		= audio.loadSound( "sound_alif.wav" )
local sound_kaf 		= audio.loadSound( "sound_alif.wav" )
local sound_kaaf 		= audio.loadSound( "sound_alif.wav" )
local sound_ghaaf 		= audio.loadSound( "sound_alif.wav" )
local sound_lam 		= audio.loadSound( "sound_alif.wav" )
local sound_mem 		= audio.loadSound( "sound_alif.wav" )
local sound_noon 		= audio.loadSound( "sound_alif.wav" )
local sound_wao 		= audio.loadSound( "sound_alif.wav" )
local sound_hay 		= audio.loadSound( "sound_alif.wav" )
local sound_humza 		= audio.loadSound( "sound_alif.wav" )
local sound_chotiyey 	= audio.loadSound( "sound_alif.wav" )
local sound_bariyey 	= audio.loadSound( "sound_alif.wav" )

local text_alif
local text_bay
local text_pay
local text_tey
local text_ttey
local text_sey
local text_jeem
local text_chey
local text_hey
local text_khey
local text_dal
local text_ddal
local text_zal
local text_rey
local text_rrey
local text_zey
local text_seen
local text_sheen
local text_suad
local text_zuad
local text_tua
local text_zua
local text_aen
local text_ghaen
local text_fey
local text_kaf
local text_kaaf
local text_ghaaf
local text_laam
local text_meem
local text_noon
local text_wao
local text_hey
local text_humza
local text_chotiyey
local text_bariyey


local function invisible_all()
	text_alif.isVisible = false
	text_bay.isVisible = false
	text_pay.isVisible = false
--	text_tey.isVisible = false
--	text_ttey.isVisible = false
--	text_sey.isVisible = false
--	text_jeem.isVisible = false
--	text_chey.isVisible = false
--	text_hey.isVisible = false
--	text_khey.isVisible = false
--	text_dal.isVisible = false
--	text_ddal.isVisible = false
--	text_zal.isVisible = false
--	text_rey.isVisible = false
--	text_rrey.isVisible = false
--	text_zey.isVisible = false
--	text_ssey.isVisible = false
--	text_seen.isVisible = false
--	text_sheen.isVisible = false
--	text_suad.isVisible = false
--	text_zuad.isVisible = false
--	text_tua.isVisible = false
--	text_zua.isVisible = false
--	text_aen.isVisible = false
--	text_ghen.isVisible = false
--	text_fey.isVisible = false
--	text_kaf.isVisible = false
--	text_kaaf.isVisible = false
--	text_ghaaf.isVisible = false
--	text_laam.isVisible = false
--	text_meem.isVisible = false
--	text_noon.isVisible = false
--	text_wao.isVisible = false
--	text_hay.isVisible = false
--	text_humza.isVisible = false
--	text_chotiyey.isVisible = false
--	text_bariyey.isVisible = false
end	


-- Your code here
-- Set default fill color for vector objects to red
-- display.setDefault( "fillColor", 1, 0, 0 )
local function play_alif_sound()
	audio.play( sound_alif )
	invisible_all()
	text_alif.isVisible = true
end


local function play_bay_sound()
	audio.play( sound_bay )
	invisible_all()
    text_bay.isVisible = true
end


local function play_pay_sound()
	audio.play( sound_say )
	invisible_all()
    text_pay.isVisible = true
end


-- display.setDefault("background", 1,1,1 )

-- SANI: Loads and displays an background image on the screen.
local background 	= display.newImageRect( "background_brown.jpg", 320, 480 )
background.x 		= display.contentCenterX -- SANI:  Horizontal center
background.y 		= display.contentCenterY -- SANI: Verticle center


-- START 
-- SANI: Show status bar 
display.setStatusBar( display.DefaultStatusBar )
-- SANI: Load widget library
local widget 			= require( "widget" )
-- SANI: configure scroll view
    local scrollView 	= widget.newScrollView
    {
        --left 						= 0,
        --top 						= 0,
        --width 					= display.contentWidth,
        --height 					= display.contentHeight,
        id 							= "onBottom",
        horizontalScrollDisabled 	= false,
        verticalScrollDisabled 		= false,
        listener 					= scrollListener,
        backgroundColor 			= { 0, 0, 0, 0 },
        left 						= display.contentWidth/2-50,
        top 						= display.contentHeight/2-165,
        width 						= 180,
        height 						= 300,
        bottomPadding 				= 10,
    }

local centerX_Row1 = 110
local centerX_Row2 = 110
local shows        = {}
local length       = 37;

function displayShow( event )
    
	local params = event.target

	if params.letter_sound == "alif" then 
		audio.play( sound_alif )
	elseif params.letter_sound == "bay" then 
		audio.play( sound_bay )
	else 
		audio.play( sound_alif )	
	end
	
end

-- SANI: create an array of alphabets & their images
alphabets_letters = {"alif", "bay", "pay", "tey", "ttey", "sey", "jeem", "chey", "hey", "khey", "dal", "ddal", "zal", "rey", "rrey", "zay", "ssey", "seen", "sheen", "suad", "zuad", "tua", "zua", "aen", "ghaen", "fey", "kaf", "kaaf", "ghaaf", "laam", "meem", "noon", "wao", "hay", "humza", "chotiyey", "bariyey"} 
letter_images 	  = {"apple.png","apple.png","apple.png","apple.png","apple.png","apple.png","apple.png","apple.png","apple.png","apple.png","apple.png","apple.png","apple.png","apple.png","apple.png","apple.png","apple.png","apple.png","apple.png","apple.png","apple.png","apple.png","apple.png","apple.png","apple.png","apple.png","apple.png","apple.png","apple.png","apple.png","apple.png","apple.png","apple.png","apple.png","apple.png","apple.png","apple.png"}

-- SANI: Store alphabets & images into another variable
for k = 1,length,1 do
    shows[k] 				 = {}
    shows[k].alphabets_name  = "urdu_alphabets_black_png/"..alphabets_letters[k]..".png"
    shows[k].alphabets_image = "fruits/"..letter_images[k]
end

-- SANI: Loop through variable
for k = 1,#shows,1 do
	
    --MAke a alphabets letter group and show on screen
    local group 		= display.newGroup();
    local letter_text  	= display.newImageRect(shows[k].alphabets_name,102,70)
    group:insert(letter_text)
    group.x 			= centerX_Row1-30
    group.y 			= 100
    centerX_Row1 		= centerX_Row1 + 190
    group.letter_sound  = alphabets_letters[k]
    group:addEventListener( "tap", displayShow)
    scrollView:insert( group )
    
    --MAke a alphabets image group and show on screen
    local group_images   = display.newGroup();
    local letter_image   = display.newImageRect(shows[k].alphabets_image,150,150)
    group_images:insert(letter_image)
    group_images:addEventListener( "tap", displayShow)
    group_images.x 		 = centerX_Row2-20
    group_images.y 		 = 220
    centerX_Row2 		 = centerX_Row2 + 190
    group_images.letter_sound  = alphabets_letters[k]
    scrollView:insert( group_images )

end






