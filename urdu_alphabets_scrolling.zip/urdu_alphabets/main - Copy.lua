-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------
local sound_alif 		= audio.loadSound( "alphabets_sounds/alif.wav" )
local sound_bay 		= audio.loadSound( "alphabets_sounds/bay.wav" )
local sound_pay 		= audio.loadSound( "alphabets_sounds/alif.wav" )
local sound_tey 		= audio.loadSound( "sound_alif.wav" )
local sound_ttey 		= audio.loadSound( "sound_alif.wav" )
local sound_sey 		= audio.loadSound( "sound_alif.wav" )
local sound_jeem 		= audio.loadSound( "sound_alif.wav" )
local sound_chey 		= audio.loadSound( "sound_alif.wav" )
local sound_hey 		= audio.loadSound( "sound_alif.wav" )
local sound_khey 		= audio.loadSound( "sound_alif.wav" )
local sound_dal 		= audio.loadSound( "sound_alif.wav" )
local sound_ddal 		= audio.loadSound( "sound_alif.wav" )
local sound_zal 		= audio.loadSound( "sound_alif.wav" )
local sound_rey 		= audio.loadSound( "sound_alif.wav" )
local sound_rrey 		= audio.loadSound( "sound_alif.wav" )
local sound_zey 		= audio.loadSound( "sound_alif.wav" )
local sound_ssey 		= audio.loadSound( "sound_alif.wav" )
local sound_seen 		= audio.loadSound( "sound_alif.wav" )
local sound_sheen 		= audio.loadSound( "sound_alif.wav" )
local sound_suad 		= audio.loadSound( "sound_alif.wav" )
local sound_zuad 		= audio.loadSound( "sound_alif.wav" )
local sound_tua 		= audio.loadSound( "sound_alif.wav" )
local sound_zua 		= audio.loadSound( "sound_alif.wav" )
local sound_aen 		= audio.loadSound( "sound_alif.wav" )
local sound_ghaen 		= audio.loadSound( "sound_alif.wav" )
local sound_fey 		= audio.loadSound( "sound_alif.wav" )
local sound_kaf 		= audio.loadSound( "sound_alif.wav" )
local sound_kaaf 		= audio.loadSound( "sound_alif.wav" )
local sound_ghaaf 		= audio.loadSound( "sound_alif.wav" )
local sound_lam 		= audio.loadSound( "sound_alif.wav" )
local sound_mem 		= audio.loadSound( "sound_alif.wav" )
local sound_noon 		= audio.loadSound( "sound_alif.wav" )
local sound_wao 		= audio.loadSound( "sound_alif.wav" )
local sound_hay 		= audio.loadSound( "sound_alif.wav" )
local sound_humza 		= audio.loadSound( "sound_alif.wav" )
local sound_chotiyey 	= audio.loadSound( "sound_alif.wav" )
local sound_bariyey 	= audio.loadSound( "sound_alif.wav" )

local text_alif
local text_bay
local text_pay
local text_tey
local text_ttey
local text_sey
local text_jeem
local text_chey
local text_hey
local text_khey
local text_dal
local text_ddal
local text_zal
local text_rey
local text_rrey
local text_zey
local text_seen
local text_sheen
local text_suad
local text_zuad
local text_tua
local text_zua
local text_aen
local text_ghaen
local text_fey
local text_kaf
local text_kaaf
local text_ghaaf
local text_laam
local text_meem
local text_noon
local text_wao
local text_hey
local text_humza
local text_chotiyey
local text_bariyey


local function invisible_all()
	text_alif.isVisible = false
	text_bay.isVisible = false
	text_pay.isVisible = false
--	text_tey.isVisible = false
--	text_ttey.isVisible = false
--	text_sey.isVisible = false
--	text_jeem.isVisible = false
--	text_chey.isVisible = false
--	text_hey.isVisible = false
--	text_khey.isVisible = false
--	text_dal.isVisible = false
--	text_ddal.isVisible = false
--	text_zal.isVisible = false
--	text_rey.isVisible = false
--	text_rrey.isVisible = false
--	text_zey.isVisible = false
--	text_ssey.isVisible = false
--	text_seen.isVisible = false
--	text_sheen.isVisible = false
--	text_suad.isVisible = false
--	text_zuad.isVisible = false
--	text_tua.isVisible = false
--	text_zua.isVisible = false
--	text_aen.isVisible = false
--	text_ghen.isVisible = false
--	text_fey.isVisible = false
--	text_kaf.isVisible = false
--	text_kaaf.isVisible = false
--	text_ghaaf.isVisible = false
--	text_laam.isVisible = false
--	text_meem.isVisible = false
--	text_noon.isVisible = false
--	text_wao.isVisible = false
--	text_hay.isVisible = false
--	text_humza.isVisible = false
--	text_chotiyey.isVisible = false
--	text_bariyey.isVisible = false
end	


-- Your code here
-- Set default fill color for vector objects to red
-- display.setDefault( "fillColor", 1, 0, 0 )
local function play_alif_sound()
	audio.play( sound_alif )
	invisible_all()
	text_alif.isVisible = true
end


local function play_bay_sound()
	audio.play( sound_bay )
	invisible_all()
    text_bay.isVisible = true
end


local function play_pay_sound()
	audio.play( sound_say )
	invisible_all()
    text_pay.isVisible = true
end




-- Set default screen background color to blue
-- display.setDefault("background", 136, 193, 220, 0)
display.setDefault("background", 0.4,0.8,0.9 )

-- SANI: Loads and displays an background image on the screen.
local background = display.newImageRect( "background_blue.jpg", 370, 360 )
background.x = display.contentCenterX -- SANI:  Horizontal center
background.y = display.contentCenterY -- SANI: Verticle center


-- SANI: Blackboard
local blackboard = display.newImageRect( "blackboard.png", 300, 130 )
blackboard.x = display.contentCenterX
blackboard.y = display.contentHeight-360


text_alif = display.newImage( "urdu_alphpabets_white_png/alif.png", 102, 70 )
text_alif.x = display.contentCenterX
text_alif.y = display.contentHeight-360
text_alif.isVisible = false


text_bay = display.newImage( "urdu_alphpabets_white_png/bay.png", 102, 70 )
text_bay.x = display.contentCenterX
text_bay.y = display.contentHeight-360
text_bay.isVisible = false


text_pay = display.newImage( "urdu_alphpabets_white_png/pay.png", 102, 70 )
text_pay.x = display.contentCenterX
text_pay.y = display.contentHeight-360
text_pay.isVisible = false


-- SANI: BUTTONS URDU

-- alif
local btn_alif = display.newImageRect( "urdu_alphabets_buttons/btn_alif.jpg", 50, 50, true )
btn_alif.x = display.contentWidth-35
btn_alif.y = display.contentHeight-260
-- SANI: play sound in touch button
btn_alif:addEventListener( "touch", play_alif_sound ) -- (event name, function name)

-- bay
local btn_bay = display.newImageRect( "urdu_alphabets_buttons/btn_bay.jpg", 50, 50, true )
btn_bay.x = display.contentWidth-85
btn_bay.y = display.contentHeight-260
-- SANI: play sound in touch button
btn_bay:addEventListener( "touch", play_bay_sound ) -- (event name, function name)

-- pay
local btn_pay = display.newImageRect( "urdu_alphabets_buttons/btn_pay.jpg", 50, 50, true )
btn_pay.x = display.contentWidth-135
btn_pay.y = display.contentHeight-260
-- SANI: play sound in touch button
btn_pay:addEventListener( "touch", play_pay_sound ) -- (event name, function name)

-- tay
local btn_tay = display.newImageRect( "urdu_alphabets_buttons/btn_tey.jpg", 50, 50, true )
btn_tay.x = display.contentWidth-185
btn_tay.y = display.contentHeight-260
-- SANI: play sound in touch button
btn_tay:addEventListener( "touch", play_alif_sound ) -- (event name, function name)


-- ttay
local btn_ttay = display.newImageRect( "urdu_alphabets_buttons/btn_ttey.jpg", 50, 50, true )
btn_ttay.x = display.contentWidth-235
btn_ttay.y = display.contentHeight-260
-- SANI: play sound in touch button
btn_ttay:addEventListener( "touch", play_alif_sound ) -- (event name, function name)

-- ttay
local btn_sey = display.newImageRect( "urdu_alphabets_buttons/btn_sey.jpg", 50, 50, true )
btn_sey.x = display.contentWidth-285
btn_sey.y = display.contentHeight-260
-- SANI: play sound in touch button
btn_sey:addEventListener( "touch", play_alif_sound ) -- (event name, function name)



-- START 

local physics = require( "physics" ) -- SANI: Load module
physics.start() -- SANI: Starts the physics engine.
-- SANI: Adds a physical body to an object. 
physics.addBody( blackboard, "static" ) -- SANI: static means fixed on position







