-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here
-- SANI
local composer = require( "composer" )

display.setStatusBar( display.HiddenStatusBar )

composer.gotoScene("main_menu")