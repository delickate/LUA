-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here

-- Hide status bar
display.setStatusBar( display.HiddenStatusBar )

-- SANI: load lirbraries
-- local storyboard = require "storyboard"
-- or you can use composer instead
local composer = require( "composer" )

-- SANI: Load splash screen
local splash_screen = display.newImage("SplashScreen.png", 320, 480)
splash_screen.x 		= display.contentCenterX -- SANI:  Horizontal center
splash_screen.y 		= display.contentCenterY -- SANI: Verticle center

-- SANI: load splash screen for 4 seconds then show new screen 
-- transition.fadeOut( splash_screen, { time=1000, delay=4000, onComplete=storyboard.gotoScene("main_menu") } ) 
transition.fadeOut( splash_screen, { time=1000, delay=4000, onComplete=composer.gotoScene("main_menu") } ) 