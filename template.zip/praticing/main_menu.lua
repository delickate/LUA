-- SANI: Load library
local composer = require( "composer" )
-- SANI: Create scene object 
local menu_scene = composer.newScene()


-- SANI: Function to go to start scene
local function gotoStart()
    composer.gotoScene( "start_scene" )
end

-- SANI: Function to go to Level scene
local function gotoLevels()
    composer.gotoScene( "level_scene" )
end

-- SANI: Function to go to Score scene
local function gotoScores()
    composer.gotoScene( "scores_scene" )
end

-- SANI: Function to go to Quite scene
local function gotoQuite()
     timer.performWithDelay(1000,quite) 
end

-- SANI: Function to quite game
function quite() 
 os.exit() 
end 

function menu_scene:create( event )
 
    local sceneGroup = self.view
    -- Code here runs when the scene is first created but has not yet appeared on screen
 
    -- SANI: Display start text on screen
	local start_Text = display.newText(sceneGroup, "Start", display.contentCenterX, 20, native.systemFont, 40 )
	start_Text:setFillColor( 0.75, 0.78, 1 )

	-- SANI: Display Level text on screen
	local level_Text = display.newText(sceneGroup, "Levels", display.contentCenterX, 80, native.systemFont, 40 )
	level_Text:setFillColor( 0.75, 0.78, 1 )

	-- SANI: Display Score text on screen
	local score_Text = display.newText(sceneGroup, "Scores", display.contentCenterX, 140, native.systemFont, 40 )
	score_Text:setFillColor( 0.75, 0.78, 1 )

	-- SANI: Display quite text on screen
	local quite_Text = display.newText(sceneGroup, "Quite", display.contentCenterX, 200, native.systemFont, 40 )
	quite_Text:setFillColor( 0.75, 0.78, 1 )

	-- SANI: listen tap event for all texts
	start_Text:addEventListener( "tap", gotoStart )
	level_Text:addEventListener( "tap", gotoLevels )
	score_Text:addEventListener( "tap", gotoScores )
	quite_Text:addEventListener( "tap", gotoQuite )
end

-- SANI: show scene
function menu_scene:show( event )

    local sceneGroup = self.view
    local phase = event.phase

    if ( phase == "will" ) then
        -- Called when the scene is still off screen (but is about to come on screen).
    elseif ( phase == "did" ) then
        -- Called when the scene is now on screen.
        -- Insert code here to make the scene come alive.
        -- Example: start timers, begin animation, play audio, etc.
    end
end

-- SANI: hide scene
function menu_scene:hide( event )

    local sceneGroup = self.view
    local phase = event.phase

    if ( phase == "will" ) then
        -- Called when the scene is on screen (but is about to go off screen).
        -- Insert code here to "pause" the scene.
        -- Example: stop timers, stop animation, stop audio, etc.
    elseif ( phase == "did" ) then
        -- Called immediately after scene goes off screen.
    end
end


-- SANI:  destroy
function menu_scene:destroy( event )

    local sceneGroup = self.view

    -- Called prior to the removal of scene's view ("sceneGroup").
    -- Insert code here to clean up the scene.
    -- Example: remove display objects, save state, etc.
end


 -- SANI: Event listern for scene
menu_scene:addEventListener( "create", menu_scene )
menu_scene:addEventListener( "show", menu_scene )
menu_scene:addEventListener( "hide", menu_scene )
menu_scene:addEventListener( "destroy", menu_scene )


return menu_scene