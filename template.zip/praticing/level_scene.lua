local composer = require( "composer" )
-- SANI: variable to create scene 
local level_scene = composer.newScene()
-- SANI: Function to go main menu
local function gotoMain()
    composer.gotoScene( "main_menu" )
end
-- SANI: create scence
function level_scene:create( event )
 
    local sceneGroup = self.view
    -- Code here runs when the scene is first created but has not yet appeared on screen
 
    -- Display text on screen
	local start_Text = display.newText(sceneGroup, "Level 1", display.contentCenterX, 20, native.systemFont, 40 )
	start_Text:setFillColor( 0.75, 0.78, 1 )


    -- Display text on screen
    local back_Text = display.newText(sceneGroup, "Back", display.contentCenterX, 80, native.systemFont, 40 )
    start_Text:setFillColor( 0.75, 0.78, 1 )

	back_Text:addEventListener( "tap", gotoMain )
end

-- SANI: Show scene
function level_scene:show( event )

    local sceneGroup = self.view
    local phase = event.phase

    if ( phase == "will" ) then
        -- Called when the scene is still off screen (but is about to come on screen).
    elseif ( phase == "did" ) then
        -- Called when the scene is now on screen.
        -- Insert code here to make the scene come alive.
        -- Example: start timers, begin animation, play audio, etc.
    end
end

-- SANI: hide scene
function level_scene:hide( event )

    local sceneGroup = self.view
    local phase = event.phase

    if ( phase == "will" ) then
        -- Called when the scene is on screen (but is about to go off screen).
        -- Insert code here to "pause" the scene.
        -- Example: stop timers, stop animation, stop audio, etc.
    elseif ( phase == "did" ) then
        -- Called immediately after scene goes off screen.
    end
end


-- SANI: Destroy scene
function level_scene:destroy( event )

    local sceneGroup = self.view

    -- Called prior to the removal of scene's view ("sceneGroup").
    -- Insert code here to clean up the scene.
    -- Example: remove display objects, save state, etc.
end

-- SANI: Events listning
level_scene:addEventListener( "create", level_scene )
level_scene:addEventListener( "show", level_scene )
level_scene:addEventListener( "hide", level_scene )
level_scene:addEventListener( "destroy", level_scene )


return level_scene